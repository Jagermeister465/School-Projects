#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <chrono>
#include <list>

using namespace std;
using namespace std::chrono;

const int MAX_CITIES = 500;

struct city_location {
    int x;
    int y;
};

float distance( int i, int j, city_location cities[] );

float distance_for_tour_from_i_to_j( int i, int j, float distance_travelled[][MAX_CITIES], city_location cities[],
                                     bool have_swapped, list<int>& order_travelled);

int main(int argc, char* argv[])
{
    //Some error checking on argc.
    //File opening error checking will beincluded in the duration of the program.

    if( argc != 3 )
    {
        cout << "Incorrect command line usage, please use the following:" << endl;
        cout << "BETSP.exe 'Input_File'.in 'Output_File'.out" << endl;
        system("pause");
        return 1;
    }

    auto start = high_resolution_clock::now();

    ifstream city_input;
    ofstream tour_output;
    int num_cities;
    city_location cities[MAX_CITIES];
    float distance_travelled[MAX_CITIES][MAX_CITIES];
    float tour_distance;
    list<int> order_travelled;

    //Additional error checking to ensure the files are opened properly before using them.

    city_input.open(argv[1]);
    if( city_input.fail() )
    {
        cout << "Error opening file: " << argv[1] << endl;
        return 2;
    }

    tour_output.open(argv[2]);
    if( tour_output.fail() )
    {
        cout << "Error opening file: " << argv[2] << endl;
        return 3;
    }

    //Initiallize distance travelled to all zeros;
    for( int i = 0; i < MAX_CITIES; i++ )
    {
        for( int j = 0; j < MAX_CITIES; j++ )
        {
            distance_travelled[i][j] = 0;
        }
    }

    //Make order_travelled hold nothing, so push_front and push_back work as intended.
    order_travelled.resize(0);

    //Read the first value in the file to get the number of cities.
    city_input >> num_cities;

    //If the file holds more cities than the max allowed, lower the number to the max.
    if( num_cities > MAX_CITIES )
    {
        num_cities = MAX_CITIES;
    }

    //Insert num_cities - 1 (zero indexed num_cities) into the list.
    order_travelled.push_back(num_cities - 1);

    //Read the cities coordinates into the cities array.
    for( int i = 0; i < num_cities; i++ )
    {
        city_input >> cities[i].x >> cities[i].y;
    }

    //Fill in the distance from the N-1th city to the furthest right city + every other city to furthest city.
    //Because N is indexed from one, but cities from 0, N-1 is really N-2, and N is really N-1.
    //distance_travelled[i][j] is how far one salesman travels to get from the leftmost city (0) to i and
    //another salesman from 0 to j.

    for( int j = 0; j < (num_cities - 2); j++ )
    {
        distance_travelled[num_cities - 2][j] = distance(num_cities - 2, num_cities - 1, cities) + distance(j, num_cities - 1, cities);
    }

    //The above gets us the distance from the second right most city to the right most city + every other point to the right most city.
    //This means we have every possible convergence at the right most point between the second right most point and another point.

    //Now we want to start with both salesmen at 0, and say one of you is moving to city 1.  Go there, and add the distance to the tour.
    //Then we want to say, with the new locations, one of you is moving to city 2.  Go there, and add the distance to the tour.
    //We keep moving one of the two to the next city to the right until we get to a scenario where the next city is the right most one.
    //In that case, we have already calculated closing the tour.  Pull the data and recurse.
/*
    for( int x : order_travelled )
    {
        cout << x << endl;
    }
*/
    tour_distance = distance_for_tour_from_i_to_j(0, 0, distance_travelled, cities, false, order_travelled);
/*
    for( int x : order_travelled )
    {
        cout << x << endl;
    }
*/
    tour_output << tour_distance << endl;

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(stop - start);
    tour_output << duration.count() << endl;

    return 0;
}

float distance( int i, int j, city_location cities[] )
{
    float dist = 0;
    int delta_x = 0;
    int delta_y = 0;
    int x_squared = 0;
    int y_squared = 0;

    delta_x = cities[i].x - cities[j].x;
    delta_y = cities[i].y - cities[j].y;
    x_squared = delta_x * delta_x;
    y_squared = delta_y * delta_y;
    dist = sqrt( x_squared + y_squared );

    return dist;
}

float distance_for_tour_from_i_to_j( int i, int j, float distance_travelled[][MAX_CITIES], city_location cities[],
                                     bool have_swapped, list<int>& order_travelled)
{
    //Base Case to stop recursing.
    //If the next set of cities for the tour already has a distance, start recursing.
    if( distance_travelled[i][j] > 0 )
    {
        return distance_travelled[i][j];
    }

    //Otherwise, find the distance of the tour for this set of points.
    //There are two options.  Let the path continue from i to i+1, or let the path continue from j to i+1.
    //Either way, as points are sorted by x coordinate, i+1 will always be the next point we add to the tour.
    //This simply determines if it is better to continue from one branch or the other.

    distance_travelled[i][j] = min( distance_for_tour_from_i_to_j(i+1, j, distance_travelled, cities,
                                                                  have_swapped, order_travelled) + distance(i, i+1, cities),
                                    distance_for_tour_from_i_to_j(i+1, i, distance_travelled, cities,
                                                                  have_swapped, order_travelled) + distance(j, i+1, cities) );

    //Depending on which [i][j] has data ([i+1][j] or [i+1][i]) I can tell if the city is visited on the going or returning trip.
    //I do have to pay attention to how many times its on the returning trip though, because each time we go on the return path,
    //The paths switch names, from i to j and j to i.
/*
    if( distance_travelled[i+1][j] != 0)
    {
        if( have_swapped == false )
        {
            order_travelled.push_front(i+1);
            cout << "i+1 j false" << endl;
        }
        else
        {
            order_travelled.push_back(i+1);
            cout << "i+1 j true" << endl;
        }
    }
    else
    {
        have_swapped = !have_swapped;
        if( have_swapped == false )
        {
            order_travelled.push_back(i+1);
            cout << "i+1 i false" << endl;
        }
        else
        {
            order_travelled.push_front(i+1);
            cout << "i+1 i true" << endl;
        }
    }
*/

    //That, uh, doesn't work in the slightest.  and boy howdy do i not have the time to care.
    //As long as the actual calculated distance works, we're *fine*.
    //I mean, teach did say we could have different orders as long as the distance was correct... I'm sure no order is fine.
    //Its not an instant fail at least.

    return distance_travelled[i][j];
}